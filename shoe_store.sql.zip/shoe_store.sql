--
-- Database: `shoe_store`
--
CREATE DATABASE IF NOT EXISTS `shoe_store` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoe_store`;

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`name`, `id`) VALUES
('NIke', 13),
('Adidas', 14),
('Red Wing', 15),
('Vans', 16),
('', 17),
('Mason', 18),
('Toms', 19);

-- --------------------------------------------------------

--
-- Table structure for table `brand_store`
--

CREATE TABLE `brand_store` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brand_store`
--

INSERT INTO `brand_store` (`id`, `brand_id`, `store_id`) VALUES
(1, 14, 5),
(2, 13, 4),
(3, 15, 5),
(8, 15, 6),
(9, 14, 6),
(10, 14, 6),
(11, 15, 5),
(12, 13, 5),
(14, 14, 5),
(15, 14, 7),
(16, 15, 7),
(18, 16, 6),
(19, 13, 6);

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`name`, `id`) VALUES
('Payless', 4),
('Footlocker', 5),
('Doc Martens', 6),
('Target', 7),
('Vintage House', 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brand_store`
--
ALTER TABLE `brand_store`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `brand_store`
--
ALTER TABLE `brand_store`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
